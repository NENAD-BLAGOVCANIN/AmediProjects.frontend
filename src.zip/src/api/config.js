export const apiUrl = process.env.REACT_APP_API_URL;
export const frontendUrl = process.env.REACT_APP_BASE_URL;
